# AGENTS.md

This file contains important information for AI coding agents working on the QTodoTxt2 codebase.

## Project Overview

QTodoTxt2 is a cross-platform GUI application for managing todo.txt files, built with Python 3 and PyQt5. It supports task management with contexts (@), projects (+), priorities (A-Z), due dates, and recurring tasks.

**Key Details:**
- Python version: 3.3+ (tested with 3.4 in CI)
- GUI Framework: PyQt5
- License: GPLv3+
- Entry Point: `qtodotxt2.app:run`

## Build/Install Commands

```bash
# Install dependencies
pip install python-dateutil PyQt5

# Or use system packages (preferred for PyQt5)
apt-get install python3-pyqt5 python3-dateutil

# Install package in development mode
pip install -e .
```

## Testing Commands

```bash
# Run all tests
pytest tests
# or
py.test-3 tests

# Run a single test file
pytest tests/test_file.py

# Run a specific test
pytest tests/test_file.py::TestFile::test_single_task

# Run tests with verbose output
pytest -v tests
```

**Testing Framework:** unittest (Python standard library)
- Test files are in `tests/` directory
- All test files follow pattern `test_*.py`
- Test classes extend `unittest.TestCase`
- Tests use `setUp()` and `tearDown()` methods for fixtures
- Temporary files created with `tempfile.mkstemp()`

## Linting Commands

```bash
# Run flake8 linting
flake8 qtodotxt2/ tests/

# Flake8 configuration (from tox.ini):
# - max-line-length: 120 characters
```

## Code Style Guidelines

### Import Style

Group imports in this order with blank lines between groups:

```python
# 1. Standard library imports
import argparse
import logging
import sys
import os
from datetime import datetime, date, timedelta

# 2. Third-party imports
from PyQt5 import QtCore, QtWidgets, QtGui
from PyQt5.QtQml import QQmlApplicationEngine
from dateutil.relativedelta import relativedelta

# 3. Local application imports
import qtodotxt2.qTodoTxt_style_rc
from qtodotxt2.main_controller import MainController
from qtodotxt2.lib.file import FileObserver
```

### Naming Conventions

- **Functions/Methods**: `snake_case` - `def get_all_contexts()`, `def save_and_reload()`
- **Classes**: `PascalCase` - `class Task`, `class MainController`
- **Constants**: `UPPER_CASE` - `PYTHON_VERSION`, `MAXYEAR`
- **Variables**: `snake_case` - `self.tmpfile`, `system_locale_name`
- **Private methods**: Single leading underscore - `def _parse_args()`
- **Boolean variables**: Use prefix `is_` - `is_complete`, `is_paused`

### Code Formatting

- Maximum line length: **120 characters**
- 4 spaces for indentation (no tabs)
- Two blank lines before top-level function/class definitions
- One blank line before method definitions within a class
- Use blank lines between logical sections within functions

### Type Annotations

- **NO type hints** are used in this codebase (Python 3.3+ compatibility)
- Function signatures should be clean without type annotations
- Document types in docstrings when necessary

### Error Handling

Use specific exception types:

```python
# Good
try:
    remove(self.tmpfile)
except FileNotFoundError:
    pass
except OSError as ex:
    if ex.errno != 2:
        raise

# Bad
try:
    remove(self.tmpfile)
except:
    pass  # Too broad
```

### Logging

- Use `logging` module, not `print()` for debug/info messages
- Get logger at module level in `lib/__init__.py` pattern
- Use appropriate log levels: DEBUG, INFO, WARNING, ERROR
- For deprecation warnings, use the `@deprecated` decorator from `qtodotxt2/lib/__init__.py`

### PyQt5 Specific Patterns

- Import specific components from PyQt5 modules
- Use Qt signal/slot mechanism for event handling
- Access Qt resources via compiled resource files (`.qrc` → `_rc.py`)
- UI is defined in QML files (see `qtodotxt2/qml/`)

## Project Structure

```
qtodotxt2/
├── app.py                 # Main application entry point
├── main_controller.py     # Main controller logic
├── filters_controller.py  # Filters UI controller
├── lib/                   # Core library modules
│   ├── __init__.py       # Utility functions (logger, deprecated decorator)
│   ├── file.py           # File I/O operations
│   ├── tasklib.py        # Task model and business logic
│   ├── filters.py        # Task filtering implementation
│   ├── task_htmlizer.py  # HTML generation for tasks
│   └── tendo_singleton.py # Single instance enforcement
├── qml/                  # QML UI files
├── controllers/          # Additional controllers
├── tests/                # Unit tests
├── bin/                  # Scripts
└── i18n/                # Translations
```

## Dependencies

- **PyQt5**: GUI framework
- **python-dateutil**: Date parsing and manipulation
- **tendo**: Single instance enforcement

## Git Submodules

This project uses Git submodules (currently empty configuration). Be aware of `.gitmodules` file if adding dependencies.

## Testing Patterns

When writing tests:

1. Use descriptive test method names: `test_single_task`, `test_get_all_contexts`
2. Test both success and failure cases
3. Use temporary files for file I/O tests
4. Clean up resources in `tearDown()`
5. Sort tasks and compare lists when order matters
6. Use `self.assertEqual()`, `self.assertTrue()`, `self.assertFalse()`, `self.assertGreater()`, `self.assertLess()`

Example test structure:
```python
class TestFeature(unittest.TestCase):
    def setUp(self):
        self.test_data = setup_test_environment()
    
    def tearDown(self):
        cleanup_test_environment(self.test_data)
    
    def test_specific_behavior(self):
        result = function_under_test()
        self.assertEqual(expected_value, result)
```

## No Existing AI Rules

- No `.cursorrules` file found
- No `.cursor/rules/` directory found
- No `.github/copilot-instructions.md` found

---

**Generated by AI coding assistant for future AI agents working on this repository.**
