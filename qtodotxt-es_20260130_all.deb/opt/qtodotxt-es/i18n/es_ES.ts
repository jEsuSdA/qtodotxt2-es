<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES" sourcelanguage="en">
<context>
    <name>MainController</name>
    <message>
        <location filename="../qtodotxt/ui/controllers/main_controller.py" line="70"/>
        <source>Show &amp;Filters</source>
        <translation type="obsolete">Mostrar &amp;Filtros</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/main_controller.py" line="328"/>
        <source>Unsaved changes...</source>
        <translation type="obsolete">Cambios sin guardar...</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/main_controller.py" line="402"/>
        <source>Revert to saved file (and lose unsaved changes)?</source>
        <translation type="obsolete">¿Revertir al archivo guardado (y perder los cambios no guardados)?</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/main_controller.py" line="416"/>
        <source>Current file &apos;{}&apos; is not available.
Exception: {}</source>
        <translation type="obsolete">El archivo '{}' no está disponible.
Excepción: {}</translation>
    </message>
    <message>
        <location filename="../qtodotxt2/main_controller.py" line="293"/>
        <source>Error opening file: {}.
 Exception:{}</source>
        <translation>Error al abrir el archivo: {}.
Excepción: {}</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/main_controller.py" line="76"/>
        <source>Show future &amp;Tasks</source>
        <translation type="obsolete">Mostrar &amp;Tareas futuras</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/main_controller.py" line="82"/>
        <source>Show &amp;Completed tasks</source>
        <translation type="obsolete">Mostrar tareas &amp;Completadas</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/main_controller.py" line="88"/>
        <source>&amp;Archive completed tasks</source>
        <translation type="obsolete">&amp;Archivar tareas completadas</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/main_controller.py" line="93"/>
        <source>Show tool&amp;Bar</source>
        <translation type="obsolete">Mostrar &amp;Barra de herramientas</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/main_controller.py" line="98"/>
        <source>Show search bar</source>
        <translation type="obsolete">Mostrar barra de búsqueda</translation>
    </message>
</context>
<context>
    <name>MenuController</name>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="26"/>
        <source>&amp;File</source>
        <translation type="obsolete">&amp;Archivo</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="67"/>
        <source>&amp;Edit</source>
        <translation type="obsolete">&amp;Editar</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="82"/>
        <source>&amp;View</source>
        <translation type="obsolete">&amp;Ver</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="91"/>
        <source>&amp;Help</source>
        <translation type="obsolete">A&amp;yuda</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="103"/>
        <source>&amp;Shortcuts list</source>
        <translation type="obsolete">Lista de atajo&amp;s</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="119"/>
        <source>&amp;New</source>
        <translation type="obsolete">&amp;Nuevo</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="128"/>
        <source>&amp;Open</source>
        <translation type="obsolete">&amp;Abrir</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="136"/>
        <source>&amp;Save</source>
        <translation type="obsolete">&amp;Guardar</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="144"/>
        <source>&amp;Revert</source>
        <translation type="obsolete">&amp;Revertir</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="151"/>
        <source>&amp;Preferences</source>
        <translation type="obsolete">&amp;Preferencias</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/menu_controller.py" line="159"/>
        <source>E&amp;xit</source>
        <translation type="obsolete">&amp;Salir</translation>
    </message>
</context>
<context>
    <name>SettingsUI</name>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="108"/>
        <source>QTodoTxt Settings</source>
        <translation type="obsolete">Configuración de QTodoTxt</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="109"/>
        <source>Autosave</source>
        <translation type="obsolete">Autoguardado</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="110"/>
        <source>AutoArchive</source>
        <translation type="obsolete">Autoarchivado</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="111"/>
        <source>Add created date</source>
        <translation type="obsolete">Añadir fecha de creación</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="112"/>
        <source>Ask for confirmation before task completion</source>
        <translation type="obsolete">Pedir confirmación antes de completar tarea</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="114"/>
        <source>Lowest task priority</source>
        <translation type="obsolete">Prioridad de tarea más baja</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="120"/>
        <source>Close</source>
        <translation type="obsolete">Cerrar</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="107"/>
        <source>SettingsUI</source>
        <translation type="obsolete">SettingsUI</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="113"/>
        <source>Show Delete action (Require restart)</source>
        <translation type="obsolete">Mostrar acción Eliminar (Requiere reiniciar)</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="115"/>
        <source>Use popup dialogs to create and modify tasks</source>
        <translation type="obsolete">Usar diálogos emergentes para crear y modificar tareas</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="116"/>
        <source>Enable system tray (Require restart)</source>
        <translation type="obsolete">Habilitar bandeja de sistema (Requiere reiniciar)</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="117"/>
        <source>Hide to tray</source>
        <translation type="obsolete">Ocultar en la bandeja</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="118"/>
        <source>Hide on startupp</source>
        <translation type="obsolete">Ocultar al inicio</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="121"/>
        <source>Singleton mode</source>
        <translation type="obsolete">Modo de instancia única</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/settingsui.py" line="122"/>
        <source>Theme</source>
        <translation type="obsolete">Tema</translation>
    </message>
</context>
<context>
    <name>Shortcuts</name>
    <message>
        <location filename="../qtodotxt/ui/dialogs/shortcuts.py" line="24"/>
        <source>Comment</source>
        <translation type="obsolete">Comentario</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/shortcuts.py" line="25"/>
        <source>Shortcut</source>
        <translation type="obsolete">Atajo</translation>
    </message>
</context>
<context>
    <name>ShortcutsUI</name>
    <message>
        <location filename="../qtodotxt/ui/dialogs/shortcutsui.py" line="47"/>
        <source>Shortcuts</source>
        <translation type="obsolete">Atajos</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/shortcutsui.py" line="48"/>
        <source>Shortcuts list</source>
        <translation type="obsolete">Lista de atajos</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/dialogs/shortcutsui.py" line="49"/>
        <source>Close</source>
        <translation type="obsolete">Cerrar</translation>
    </message>
</context>
<context>
    <name>TasksListController</name>
    <message>
        <location filename="../qtodotxt/ui/controllers/tasks_list_controller.py" line="73"/>
        <source>&amp;Edit Task</source>
        <translation type="obsolete">&amp;Editar Tarea</translation>
    </message>
    <message>
        <location filename="../qtodotxt/ui/controllers/tasks_list_controller.py" line="228"/>
        <source>Delete</source>
        <translation type="obsolete">Eliminar</translation>
    </message>
</context>
</TS>
